          <div class="row">
            <div class="col-lg-12">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-12">
                      <form action="#">
                        <div class="form-group d-flex">
                          <input type="text" class="form-control" placeholder="Search Here" value="Urbanui">
                          <button type="submit" class="btn btn-primary ml-3">Search</button>
                        </div>
                      </form>
                    </div>
                    <div class="col-12 mb-5">
                      <h2>Search Result For<u class="ml-2">"Urbanui"</u></h2>
                      <p class="text-muted">About 12,100 results (0.52 seconds)</p>
                    </div>

  <!--                     <div class="col-12 results">
                            <ul class="list-unstyled list-seperated t-4 border-bottom">
                              <li>
                                <div class="row">
                                  <div class="col-4 overflow-hidden">
                                    <img width="90%" height="90%" max-width="100%" src="assets/check.jpg">
                                  </div>
                                  <div class="col-8 wrap">
                                        <img src="assets/check.jpg" class="avatar">
                                        <span><a href="#">fil303</a></span>
                                        <span>|</span>
                                        <span>05/06/2021</span>
                                        <br>
                                        <span>Understanding Your Dog for Dummies CheatsheetUnderstanding Your Dog for Dummies Cheatsheet</span>
                                  </div>
                                </div>
                              </li>   
                            </ul>
                      </div>
                      
                      <div class="col-12 results">
                            <ul class="list-unstyled list-seperated t-4 border-bottom">
                              <li>
                                <div class="row">
                                  <div class="col-4 overflow-hidden">
                                    <img width="90%" height="90%" max-width="100%" src="assets/check.jpg">
                                  </div>
                                  <div class="col-8 wrap">
                                        <img src="assets/check.jpg" class="avatar">
                                        <span><a href="#">fil303</a></span>
                                        <span>|</span>
                                        <span>05/06/2021</span>
                                        <br>
                                        <span>Understanding Your Dog for Dummies CheatsheetUnderstanding Your Dog for Dummies Cheatsheet</span>
                                  </div>
                                </div>
                              </li>   
                            </ul>
                      </div>
                      
                      <div class="col-12 results">
                            <ul class="list-unstyled list-seperated t-4 border-bottom">
                              <li>
                                <div class="row">
                                  <div class="col-4 overflow-hidden">
                                    <img width="90%" height="90%" max-width="100%" src="assets/check.jpg">
                                  </div>
                                  <div class="col-8 wrap">
                                        <img src="assets/check.jpg" class="avatar">
                                        <span><a href="#">fil303</a></span>
                                        <span>|</span>
                                        <span>05/06/2021</span>
                                        <br>
                                        <span>Understanding Your Dog for Dummies CheatsheetUnderstanding Your Dog for Dummies Cheatsheet</span>
                                  </div>
                                </div>
                              </li>   
                            </ul>
                      </div> -->


         <div class="card-columns">
            <div class="card">
              <img class="card-img-top" src="assets/check.jpg" alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">
                    <img src="assets/check.jpg" class="avatar">
                    <span><a href="#">fil303</a></span>
                    <span>|</span>
                    <span>05/06/2021</span>
                </h4>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad blanditiis quam, sequi dolorum excepturi repudiandae atque dignissimos voluptatum aperiam!</p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src="assets/check.jpg" alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">
                    <img src="assets/check.jpg" class="avatar">
                    <span><a href="#">fil303</a></span>
                    <span>|</span>
                    <span>05/06/2021</span>
                </h4>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad blanditiis quam, sequi dolorum excepturi repudiandae atque dignissimos voluptatum aperiam!</p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src="assets/check.jpg" alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">
                    <img src="assets/check.jpg" class="avatar">
                    <span><a href="#">fil303</a></span>
                    <span>|</span>
                    <span>05/06/2021</span>
                </h4>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad blanditiis quam, sequi dolorum excepturi repudiandae atque dignissimos voluptatum aperiam!</p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src="assets/check.jpg" alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">
                    <img src="assets/check.jpg" class="avatar">
                    <span><a href="#">fil303</a></span>
                    <span>|</span>
                    <span>05/06/2021</span>
                </h4>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad blanditiis quam, sequi dolorum excepturi repudiandae atque dignissimos voluptatum aperiam!</p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src="assets/check.jpg" alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">
                    <img src="assets/check.jpg" class="avatar">
                    <span><a href="#">fil303</a></span>
                    <span>|</span>
                    <span>05/06/2021</span>
                </h4>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad blanditiis quam, sequi dolorum excepturi repudiandae atque dignissimos voluptatum aperiam!</p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src="assets/check.jpg" alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">
                    <img src="assets/check.jpg" class="avatar">
                    <span><a href="#">fil303</a></span>
                    <span>|</span>
                    <span>05/06/2021</span>
                </h4>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad blanditiis quam, sequi dolorum excepturi repudiandae atque dignissimos voluptatum aperiam!</p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src="assets/check.jpg" alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">
                    <img src="assets/check.jpg" class="avatar">
                    <span><a href="#">fil303</a></span>
                    <span>|</span>
                    <span>05/06/2021</span>
                </h4>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad blanditiis quam, sequi dolorum excepturi repudiandae atque dignissimos voluptatum aperiam!</p>
              </div>
            </div>
          </div>



                      
                      
                    <nav class="col-12" aria-label="Page navigation">
                      <ul class="pagination mt-5">
                        <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                        <li class="page-item  active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item"><a class="page-link" href="#">Next</a></li>
                      </ul>
                    </nav>
                  </div>
                </div>
              </div>
            </div>
          </div>