     </div>
  <!-- Main Body End -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2018 <a href="https://www.urbanui.com/" target="_blank">Urbanui</a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="mdi mdi-heart text-danger"></i></span>
          </div>
        </footer>
  
      </div>
  
    </div>
    
  </div>
  
  
    
  <script src="<?php echo ASSETS ; ?>vendors/js/vendor.bundle.base.js"></script>
  
  <script src="<?php echo ASSETS ; ?>js/off-canvas.js"></script>
  <script src="<?php echo ASSETS ; ?>vendors/owl-carousel-2/owl.carousel.min.js"></script>
  <script src="<?php echo ASSETS ; ?>js/owl-carousel.js"></script>
  <script src="<?php echo ASSETS ; ?>js/template.js"></script>
  <script type="text/javascript">
    
    $('.owl-carousel').owlCarousel({
      loop:true,
      margin:10,
      nav:true,
      autoplay:true,
      autoplayTimeout:5000,
      autoplayHoverPause:true,
      responsive:{
          0:{
              items:1
          },
          400:{
              items:1
          },
          600:{
              items:2
          },
          800:{
              items:2
          },
          1000:{
              items:3
          }
      }
    });

  </script>
  </body>

</html>
